const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const pool = require('./db');

// Buat tabel user di schema.sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(100) NOT NULL,
  role VARCHAR(20) NOT NULL -- 'admin' atau 'pegawai'
);

// Fungsi login
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const { rows } = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
    if (rows.length === 0) return res.status(401).json({ error: 'User tidak ditemukan' });

    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ error: 'Password salah' });

    const token = jwt.sign(
      { id: user.id, role: user.role },
      'rahasia_bumn', // Ganti dengan secret key kuat
      { expiresIn: '1h' }
    );
    res.json({ token, role: user.role });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Middleware verifikasi token
function authenticate(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Akses ditolak' });

  try {
    const verified = jwt.verify(token, 'rahasia_bumn');
    req.user = verified;
    next();
  } catch (err) {
    res.status(400).json({ error: 'Token tidak valid' });
  }
}

// Proteksi route (contoh: hanya admin yang bisa input gaji)
app.post('/api/gaji', authenticate, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Akses terbatas untuk admin' });
  }
  // Proses input gaji...
});