app.get('/api/stats', authenticate, async (req, res) => {
  try {
    const pegawai = await pool.query('SELECT COUNT(*) FROM pegawai');
    const cuti = await pool.query('SELECT COUNT(*) FROM cuti WHERE tanggal_mulai >= NOW() - INTERVAL \'30 days\'');
    const gaji = await pool.query('SELECT SUM(gaji_pokok + tunjangan - potongan) AS total FROM gaji WHERE bulan = DATE_TRUNC(\'month\', NOW())');
    
    res.json({
      totalPegawai: pegawai.rows[0].count,
      totalCuti: cuti.rows[0].count,
      totalGaji: gaji.rows[0].total || 0
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());

// Koneksi PostgreSQL
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'bumn_hr',
  password: 'password',
  port: 5432,
});

// API: Ambil data pegawai
app.get('/api/pegawai', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM pegawai');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// API: Tambah data pegawai
app.post('/api/pegawai', async (req, res) => {
  const { nip, nama, jabatan } = req.body;
  try {
    await pool.query(
      'INSERT INTO pegawai (nip, nama, jabatan) VALUES ($1, $2, $3)',
      [nip, nama, jabatan]
    );
    res.status(201).json({ message: 'Data tersimpan!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(5000, () => console.log('Server berjalan di port 5000'));