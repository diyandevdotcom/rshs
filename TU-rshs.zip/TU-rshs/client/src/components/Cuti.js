import { useState, useEffect } from 'react';

export default function Cuti() {
  const [cuti, setCuti] = useState([]);
  const [form, setForm] = useState({
    pegawai_id: '',
    jenis_cuti: 'tahunan',
    tanggal_mulai: '',
    tanggal_selesai: ''
  });

  // Ambil data cuti
  useEffect(() => {
    fetch('http://localhost:5000/api/cuti')
      .then(res => res.json())
      .then(data => setCuti(data));
  }, []);

  // Handle submit
  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:5000/api/cuti', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    })
      .then(res => res.json())
      .then(data => {
        alert(data.message);
        setForm({ ...form, tanggal_mulai: '', tanggal_selesai: '' });
      });
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Pengajuan Cuti</h2>
      <form onSubmit={handleSubmit} className="mb-6 p-4 bg-gray-100 rounded">
        <select
          value={form.pegawai_id}
          onChange={(e) => setForm({ ...form, pegawai_id: e.target.value })}
          className="p-2 mr-2 border rounded"
        >
          <option value="">Pilih Pegawai</option>
          {pegawai.map((p) => (
            <option key={p.id} value={p.id}>{p.nama}</option>
          ))}
        </select>
        <select
          value={form.jenis_cuti}
          onChange={(e) => setForm({ ...form, jenis_cuti: e.target.value })}
          className="p-2 mr-2 border rounded"
        >
          <option value="tahunan">Cuti Tahunan</option>
          <option value="sakit">Cuti Sakit</option>
          <option value="melahirkan">Cuti Melahirkan</option>
        </select>
        <input
          type="date"
          placeholder="Tanggal Mulai"
          value={form.tanggal_mulai}
          onChange={(e) => setForm({ ...form, tanggal_mulai: e.target.value })}
          className="p-2 mr-2 border rounded"
        />
        <input
          type="date"
          placeholder="Tanggal Selesai"
          value={form.tanggal_selesai}
          onChange={(e) => setForm({ ...form, tanggal_selesai: e.target.value })}
          className="p-2 mr-2 border rounded"
        />
        <button type="submit" className="p-2 bg-green-500 text-white rounded">
          Ajukan
        </button>
      </form>

      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2 border">Nama Pegawai</th>
            <th className="p-2 border">Jenis Cuti</th>
            <th className="p-2 border">Tanggal</th>
          </tr>
        </thead>
        <tbody>
          {cuti.map((c) => (
            <tr key={c.id}>
              <td className="p-2 border">{c.nama}</td>
              <td className="p-2 border">{c.jenis_cuti}</td>
              <td className="p-2 border">
                {new Date(c.tanggal_mulai).toLocaleDateString()} - 
                {new Date(c.tanggal_selesai).toLocaleDateString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}