import { useState } from 'react';

export default function BPJS() {
  const [form, setForm] = useState({
    nama: '',
    tanggal_lahir: '',
    nip: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:5000/api/bpjs/daftar', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify(form)
    })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          alert(`Pendaftaran BPJS berhasil! Nomor BPJS: ${data.nomor_bpjs}`);
        }
      });
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Pendaftaran BPJS Ketenagakerjaan</h2>
      <form onSubmit={handleSubmit} className="max-w-md">
        <input
          type="text"
          placeholder="NIP"
          value={form.nip}
          onChange={(e) => setForm({ ...form, nip: e.target.value })}
          className="w-full p-2 mb-3 border rounded"
        />
        <input
          type="text"
          placeholder="Nama Lengkap"
          value={form.nama}
          onChange={(e) => setForm({ ...form, nama: e.target.value })}
          className="w-full p-2 mb-3 border rounded"
        />
        <input
          type="date"
          placeholder="Tanggal Lahir"
          value={form.tanggal_lahir}
          onChange={(e) => setForm({ ...form, tanggal_lahir: e.target.value })}
          className="w-full p-2 mb-3 border rounded"
        />
        <button type="submit" className="w-full p-2 bg-green-600 text-white rounded">
          Daftar BPJS
        </button>
      </form>
    </div>
  );
}