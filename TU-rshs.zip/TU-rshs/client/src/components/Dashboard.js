import { useEffect, useState } from 'react';
import { BarChart, PieChart } from '@mui/charts'; // Atau gunakan Chart.js

export default function Dashboard() {
  const [stats, setStats] = useState({});
  const [cutiData, setCutiData] = useState([]);

  useEffect(() => {
    // Ambil statistik
    fetch('http://localhost:5000/api/stats', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    })
      .then(res => res.json())
      .then(data => setStats(data));

    // Ambil data cuti untuk grafik
    fetch('http://localhost:5000/api/cuti')
      .then(res => res.json())
      .then(data => {
        const byJenis = data.reduce((acc, curr) => {
          acc[curr.jenis_cuti] = (acc[curr.jenis_cuti] || 0) + 1;
          return acc;
        }, {});
        setCutiData(Object.entries(byJenis).map(([label, value]) => ({ label, value })));
      });
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Dashboard Rekap</h2>
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="p-4 bg-blue-100 rounded">
          <h3>Total Pegawai</h3>
          <p className="text-2xl font-bold">{stats.totalPegawai || 0}</p>
        </div>
        <div className="p-4 bg-green-100 rounded">
          <h3>Cuti Bulan Ini</h3>
          <p className="text-2xl font-bold">{stats.totalCuti || 0}</p>
        </div>
        <div className="p-4 bg-yellow-100 rounded">
          <h3>Total Gaji</h3>
          <p className="text-2xl font-bold">Rp {stats.totalGaji?.toLocaleString() || 0}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-white rounded shadow">
          <h3 className="font-bold mb-2">Jenis Cuti</h3>
          <PieChart data={cutiData} width={300} height={200} />
        </div>
        <div className="p-4 bg-white rounded shadow">
          <h3 className="font-bold mb-2">Trend Pengajuan Cuti</h3>
          <BarChart /* ... */ />
        </div>
      </div>
    </div>
  );
}