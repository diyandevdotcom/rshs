import { useState } from 'react';

export default function Gaji() {
  const [form, setForm] = useState({
    pegawai_id: '',
    bulan: '',
    gaji_pokok: 0,
    tunjangan: 0,
    potongan: 0
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:5000/api/gaji', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...form,
        bulan: new Date(form.bulan).toISOString()
      })
    })
      .then(res => res.json())
      .then(data => alert(data.message));
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Input Penggajian</h2>
      <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
        <select
          value={form.pegawai_id}
          onChange={(e) => setForm({ ...form, pegawai_id: e.target.value })}
          className="p-2 border rounded"
        >
          <option value="">Pilih Pegawai</option>
          {pegawai.map((p) => (
            <option key={p.id} value={p.id}>{p.nama}</option>
          ))}
        </select>
        <input
          type="month"
          value={form.bulan}
          onChange={(e) => setForm({ ...form, bulan: e.target.value })}
          className="p-2 border rounded"
        />
        <input
          type="number"
          placeholder="Gaji Pokok"
          value={form.gaji_pokok}
          onChange={(e) => setForm({ ...form, gaji_pokok: e.target.value })}
          className="p-2 border rounded"
        />
        <input
          type="number"
          placeholder="Tunjangan"
          value={form.tunjangan}
          onChange={(e) => setForm({ ...form, tunjangan: e.target.value })}
          className="p-2 border rounded"
        />
        <input
          type="number"
          placeholder="Potongan"
          value={form.potongan}
          onChange={(e) => setForm({ ...form, potongan: e.target.value })}
          className="p-2 border rounded"
        />
        <button 
          type="submit" 
          className="col-span-2 p-2 bg-blue-500 text-white rounded"
        >
          Simpan
        </button>
      </form>
    </div>
  );
}