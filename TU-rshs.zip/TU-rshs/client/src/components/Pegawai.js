import { useState, useEffect } from 'react';

export default function Pegawai() {
  const [pegawai, setPegawai] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [filterJabatan, setFilterJabatan] = useState('');

  // Ambil data pegawai
  useEffect(() => {
    fetch('http://localhost:5000/api/pegawai')
      .then(res => res.json())
      .then(data => {
        setPegawai(data);
        setFiltered(data);
      });
  }, []);

  // Filter data
  useEffect(() => {
    let result = pegawai;
    if (search) {
      result = result.filter(p => 
        p.nama.toLowerCase().includes(search.toLowerCase()) || 
        p.nip.includes(search)
      );
    }
    if (filterJabatan) {
      result = result.filter(p => p.jabatan === filterJabatan);
    }
    setFiltered(result);
  }, [search, filterJabatan, pegawai]);

  return (
    <div className="p-4">
      <div className="flex mb-4 gap-4">
        <input
          type="text"
          placeholder="Cari NIP/Nama"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="p-2 border rounded flex-1"
        />
        <select
          value={filterJabatan}
          onChange={(e) => setFilterJabatan(e.target.value)}
          className="p-2 border rounded"
        >
          <option value="">Semua Jabatan</option>
          <option value="Manager">Manager</option>
          <option value="Staff">Staff</option>
        </select>
      </div>
      
      {/* Tampilkan tabel filtered */}
      <table className="w-full border-collapse">
        <tbody>
          {filtered.map((p) => (
            <tr key={p.id}>
              {/* ... */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}