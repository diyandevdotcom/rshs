import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

function App() {
  const isAuthenticated = !!localStorage.getItem('token');

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={!isAuthenticated ? <Login /> : <Navigate to="/dashboard" />} />
        <Route path="/" element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" />} />
        <Route path="/dashboard" element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" />} />
        <Route path="/bpjs" element={isAuthenticated ? <BPJS /> : <Navigate to="/login" />} />
      </Routes>
    </BrowserRouter>
  );
}

import { useState } from 'react';
import Pegawai from './components/Pegawai';
import Cuti from './components/Cuti';
import Gaji from './components/Gaji';

export default function App() {
  const [activeTab, setActiveTab] = useState('pegawai');

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6">HRIS BUMN</h1>
      <div className="flex gap-4 mb-6">
        <button 
          onClick={() => setActiveTab('pegawai')}
          className={`p-2 ${activeTab === 'pegawai' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
        >
          Data Pegawai
        </button>
        <button 
          onClick={() => setActiveTab('cuti')}
          className={`p-2 ${activeTab === 'cuti' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
        >
          Cuti
        </button>
        <button 
          onClick={() => setActiveTab('gaji')}
          className={`p-2 ${activeTab === 'gaji' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
        >
          Penggajian
        </button>
      </div>

      {activeTab === 'pegawai' && <Pegawai />}
      {activeTab === 'cuti' && <Cuti />}
      {activeTab === 'gaji' && <Gaji />}
    </div>
  );
}

import { useState, useEffect } from 'react';

function App() {
  const [pegawai, setPegawai] = useState([]);
  const [form, setForm] = useState({ nip: '', nama: '', jabatan: '' });

  // Ambil data pegawai
  useEffect(() => {
    fetch('http://localhost:5000/api/pegawai')
      .then(res => res.json())
      .then(data => setPegawai(data));
  }, []);

  // Handle submit form
  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:5000/api/pegawai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    })
      .then(res => res.json())
      .then(data => {
        alert(data.message);
        setForm({ nip: '', nama: '', jabatan: '' });
      });
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Admin Kepegawaian BUMN</h1>
      
      {/* Form Tambah Pegawai */}
      <form onSubmit={handleSubmit} className="mb-8 p-4 bg-gray-100 rounded">
        <input
          type="text"
          placeholder="NIP"
          value={form.nip}
          onChange={(e) => setForm({ ...form, nip: e.target.value })}
          className="p-2 mr-2 border rounded"
        />
        <input
          type="text"
          placeholder="Nama"
          value={form.nama}
          onChange={(e) => setForm({ ...form, nama: e.target.value })}
          className="p-2 mr-2 border rounded"
        />
        <input
          type="text"
          placeholder="Jabatan"
          value={form.jabatan}
          onChange={(e) => setForm({ ...form, jabatan: e.target.value })}
          className="p-2 mr-2 border rounded"
        />
        <button type="submit" className="p-2 bg-blue-500 text-white rounded">
          Simpan
        </button>
      </form>

      {/* Tabel Daftar Pegawai */}
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2 border">NIP</th>
            <th className="p-2 border">Nama</th>
            <th className="p-2 border">Jabatan</th>
          </tr>
        </thead>
        <tbody>
          {pegawai.map((p) => (
            <tr key={p.id} className="hover:bg-gray-50">
              <td className="p-2 border">{p.nip}</td>
              <td className="p-2 border">{p.nama}</td>
              <td className="p-2 border">{p.jabatan}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;