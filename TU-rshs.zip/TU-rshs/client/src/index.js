// Buat tabel gaji di schema.sql
CREATE TABLE gaji (
  id SERIAL PRIMARY KEY,
  pegawai_id INTEGER REFERENCES pegawai(id),
  bulan DATE,
  gaji_pokok DECIMAL(12, 2),
  tunjangan DECIMAL(12, 2),
  potongan DECIMAL(12, 2)
);

// API: Input gaji
app.post('/api/gaji', async (req, res) => {
  const { pegawai_id, bulan, gaji_pokok, tunjangan, potongan } = req.body;
  try {
    await pool.query(
      'INSERT INTO gaji (pegawai_id, bulan, gaji_pokok, tunjangan, potongan) VALUES ($1, $2, $3, $4, $5)',
      [pegawai_id, bulan, gaji_pokok, tunjangan, potongan]
    );
    res.status(201).json({ message: 'Data gaji tersimpan!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// API: Ambil data cuti
app.get('/api/cuti', async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT cuti.*, pegawai.nama 
      FROM cuti 
      JOIN pegawai ON cuti.pegawai_id = pegawai.id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// API: Ajukan cuti
app.post('/api/cuti', async (req, res) => {
  const { pegawai_id, jenis_cuti, tanggal_mulai, tanggal_selesai } = req.body;
  try {
    await pool.query(
      'INSERT INTO cuti (pegawai_id, jenis_cuti, tanggal_mulai, tanggal_selesai) VALUES ($1, $2, $3, $4)',
      [pegawai_id, jenis_cuti, tanggal_mulai, tanggal_selesai]
    );
    res.status(201).json({ message: 'Cuti diajukan!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});