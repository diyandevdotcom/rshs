CREATE TABLE pegawai (...);
CREATE TABLE cuti (...);
CREATE TABLE gaji (...);
CREATE TABLE users (...);  -- Untuk autentikasi
CREATE TABLE bpjs (...);   -- Integrasi BPJS

CREATE TABLE pegawai (
  id SERIAL PRIMARY KEY,
  nip VARCHAR(20) UNIQUE NOT NULL,
  nama VARCHAR(100) NOT NULL,
  jabatan VARCHAR(50),
  tanggal_masuk DATE
);

CREATE TABLE cuti (
  id SERIAL PRIMARY KEY,
  pegawai_id INTEGER REFERENCES pegawai(id),
  jenis_cuti VARCHAR(50),
  tanggal_mulai DATE,
  tanggal_selesai DATE
);