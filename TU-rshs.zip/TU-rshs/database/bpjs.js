const axios = require('axios');

app.post('/api/bpjs/daftar', authenticate, async (req, res) => {
  const { nip, nama, tanggal_lahir } = req.body;
  try {
    // Contoh request ke API BPJS (mock)
    const response = await axios.post('https://api.bpjs-ketenagakerjaan.go.id/v1/peserta', {
      nip,
      nama,
      tanggal_lahir,
      perusahaan_kode: 'BUMN123' // Kode BUMN
    }, {
      headers: { 
        'Authorization': 'Bearer token_api_bpjs',
        'Content-Type': 'application/json'
      }
    });

    // Simpan data BPJS ke database
    await pool.query(
      'INSERT INTO bpjs (pegawai_id, nomor_bpjs) VALUES ($1, $2)',
      [req.user.id, response.data.nomor_bpjs]
    );

    res.json({ success: true, nomor_bpjs: response.data.nomor_bpjs });
  } catch (err) {
    res.status(500).json({ error: 'Gagal mendaftarkan BPJS' });
  }
});